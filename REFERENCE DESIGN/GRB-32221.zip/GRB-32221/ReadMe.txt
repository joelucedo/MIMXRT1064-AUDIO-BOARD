README for GRB-32221_A1.zip

Company Part Number: 170-32221 REV A1

Date: Mon, 11 Mar 2019 02:16:21 GMT

NXP Semiconductors
6501 William Cannon Drive West
Austin, TX 78735-8598


CAD Engineer
============
Company Contact     : [full_name]
Work Phone          : 512-895-XXXX
Email               : [email]@nxp.com

CAD Manager
===========
Company Contact     : Daniel Kruczek
Work Phone          : 512-895-6081
Email               : daniel.kruczek@nxp.com

Manufacturing Program Manager
=============================
Company Contact     : [full_name]
Work Phone          : 512-895-XXXX
Email               : [email]@nxp.com

Product Engineer
================
Company Contact     : [full_name]
Work Phone          : 512-895-XXXX
Email               : [email]@nxp.com

Design for Manufacturing Engineer
=================================
Company Contact     : Andres Marquez
Work Phone          : +52(33) 3283-2100 x3068
Email               : andres.marquez@nxp.com
